import os
import json
import math
import numpy as np
import dezero
from dezero import optimizers
import dezero.functions as F
from dezero.models import MLP
import plotly.graph_objects as go

# -----------------------
# 1. 遍历 data 文件夹下所有 JSON 点云数据
# -----------------------
def load_point_cloud_dataset_auto(data_dir='data'):
    xs, ts = [], []
    classes = []
    for label, file_name in enumerate(sorted(os.listdir(data_dir))):
        if not file_name.endswith('.json'):
            continue
        cls_name = os.path.splitext(file_name)[0]  # 文件名作为类别名
        classes.append(cls_name)
        file_path = os.path.join(data_dir, file_name)
        with open(file_path, 'r', encoding='utf-8') as f:
            points = json.load(f)
        arr = np.array([[p['x'], p['y'], p['z']] for p in points], dtype=np.float32)
        xs.append(arr)
        ts.append(np.full(len(points), label, dtype=np.int32))
    x = np.vstack(xs)
    t = np.hstack(ts)
    return x, t, classes

x, t, classes = load_point_cloud_dataset_auto()

'''
# -----------------------
# 2. 模型与训练参数
# -----------------------
max_epoch = 400
batch_size = 30
lr = 0.01
model = MLP((256, 128, 64, len(classes)))
optimizer = optimizers.SGD(lr).setup(model)

data_size = len(x)
max_iter = math.ceil(data_size / batch_size)

# -----------------------
# 3. 训练循环 + 记录 loss
# -----------------------
loss_history = []

for epoch in range(max_epoch):
    index = np.random.permutation(data_size)
    sum_loss = 0
    for i in range(max_iter):
        batch_index = index[i*batch_size:(i+1)*batch_size]
        batch_x = x[batch_index]
        batch_t = t[batch_index]

        y = model(batch_x)
        loss = F.softmax_cross_entropy(y, batch_t)
        model.cleargrads()
        loss.backward()
        optimizer.update()

        sum_loss += float(loss.data) * len(batch_t)
    avg_loss = sum_loss / data_size
    loss_history.append({"epoch": epoch+1, "loss": avg_loss})
    print(f'epoch {epoch+1}, loss {avg_loss:.4f}')

# 保存权重
model.save_weights('model_weights.npz')

# 保存 loss.json
with open("loss.json", "w", encoding="utf-8") as f:
    json.dump(loss_history, f, ensure_ascii=False, indent=2)
'''


hidden_sizes = (256, 128, 64)
model = MLP(hidden_sizes + (50,))
model.load_weights('model_weights.npz')

# -----------------------
# 4. 网格预测决策边界
# -----------------------
xx, yy, zz = np.meshgrid(
    np.linspace(x[:,0].min()-0.5, x[:,0].max()+0.5, 20),
    np.linspace(x[:,1].min()-0.5, x[:,1].max()+0.5, 20),
    np.linspace(x[:,2].min()-0.5, x[:,2].max()+0.5, 20)
)
grid = np.c_[xx.ravel(), yy.ravel(), zz.ravel()]
with dezero.no_grad():
    y_pred = model(grid)
    pred_class = np.argmax(y_pred.data, axis=1)

# -----------------------
# 5. Plotly 可视化
# -----------------------
fig = go.Figure()


import matplotlib.cm as cm
num_classes = len(classes)
cmap = cm.get_cmap('hsv', num_classes)
colors = [
    f'rgb({int(r*255)}, {int(g*255)}, {int(b*255)})'
    for r, g, b, _ in [cmap(i) for i in range(num_classes)]
]
# 绘制样本点
for i, cls_name in enumerate(classes):
    mask = t == i
    fig.add_trace(go.Scatter3d(
        x=x[mask,0], y=x[mask,1], z=x[mask,2],
        mode='markers',
        marker=dict(size=4, color=colors[i]),
        name=cls_name
    ))

# 绘制决策边界
for i in range(num_classes):  # 改成动态类别数
    mask = pred_class == i
    fig.add_trace(go.Scatter3d(
        x=grid[mask,0], y=grid[mask,1], z=grid[mask,2],
        mode='markers',
        marker=dict(size=2, color=colors[i], opacity=0.2),
        name=f'决策区域 {classes[i]}'
    ))

fig.update_layout(
    scene=dict(
        xaxis_title='X', yaxis_title='Y', zaxis_title='Z'
    ),
    width=800,
    height=600
)

fig.show(renderer="browser")
