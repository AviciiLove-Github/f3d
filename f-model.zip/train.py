import json
import torch
from torch.utils.data import Dataset
from transformers import (
    AutoTokenizer, AutoModelForCausalLM, Trainer, TrainingArguments,
    DataCollatorForLanguageModeling, TrainerCallback
)
from peft import LoraConfig, get_peft_model, TaskType
from tqdm import tqdm

MODEL_NAME = "HuatuoGPT2-7B"
TRAIN_FILE = "train.json"
EVAL_FILE = "eval.json"
OUTPUT_DIR = "./Huatuogpt2-lora-sft"
MAX_LENGTH = 1024
LR = 2e-4
EPOCHS = 1
BATCH_SIZE = 2
GRAD_ACCUM_STEPS = 8
LORA_R = 16
LORA_ALPHA = 32
LORA_DROPOUT = 0.05
LOG_FILE = "train_log.json"

tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME, use_fast=False, trust_remote_code=True)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token

model = AutoModelForCausalLM.from_pretrained(
    MODEL_NAME,
    trust_remote_code=True,
    device_map="auto",
    torch_dtype=torch.float16
)

# =========================
# 自动检测 LoRA target_modules
# =========================
possible_modules = [
    name.split(".")[-1] for name, module in model.named_modules()
    if any(x in name.lower() for x in ["c_attn", "c_proj", "c_fc", "w_pack", "gate_proj", "up_proj", "down_proj"])
]
target_modules = list(set(possible_modules)) or ["gate_proj", "down_proj", "up_proj", "W_pack"]
print("✅ LoRA target_modules:", target_modules)

lora_config = LoraConfig(
    task_type=TaskType.CAUSAL_LM,
    r=LORA_R,
    lora_alpha=LORA_ALPHA,
    target_modules=target_modules,
    lora_dropout=LORA_DROPOUT,
    bias="none"
)
model = get_peft_model(model, lora_config)
model.print_trainable_parameters()

# =========================
# 数据处理
# =========================
SYSTEM_PREFIX_H = "用户: "
SYSTEM_PREFIX_A = "医生: "

def build_text_and_labels(sample):
    text_parts, label_parts = [], []

    for turn in sample.get("conversations", []):
        role, content = turn.get("from"), (turn.get("value") or "").strip()
        if not content:
            continue
        if role in ["human", "user"]:
            piece = SYSTEM_PREFIX_H + content + "\n"
            text_parts.append(piece)
            label_parts.append([0] * len(tokenizer(piece)["input_ids"]))
        else:
            piece = SYSTEM_PREFIX_A + content + tokenizer.eos_token
            text_parts.append(piece)
            label_parts.append([1] * len(tokenizer(piece)["input_ids"]))

    # 合并文本，统一编码
    full_text = "".join(text_parts)
    enc = tokenizer(full_text, truncation=True, max_length=MAX_LENGTH, padding="max_length")
    input_ids = torch.tensor(enc["input_ids"])
    attention_mask = torch.tensor(enc["attention_mask"])

    # 构建 labels，仅医生回答部分计算 loss
    piece_ids, piece_mask = [], []
    for t, m in zip(text_parts, label_parts):
        ids = tokenizer(t)["input_ids"]
        piece_ids.extend(ids)
        piece_mask.extend(m)

    piece_ids = piece_ids[:MAX_LENGTH]
    piece_mask = piece_mask[:MAX_LENGTH]
    if len(piece_ids) < MAX_LENGTH:
        pad_len = MAX_LENGTH - len(piece_ids)
        piece_ids += [tokenizer.pad_token_id] * pad_len
        piece_mask += [0] * pad_len

    labels = torch.tensor(piece_ids)
    loss_mask = torch.tensor(piece_mask)
    labels = torch.where(loss_mask == 1, labels, torch.tensor(-100))
    return {"input_ids": input_ids, "attention_mask": attention_mask, "labels": labels}

class HuatuoDataset(Dataset):
    def __init__(self, file_path):
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        self.data = [build_text_and_labels(sample) for sample in tqdm(data, desc=f"Processing {file_path}")]

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx]

train_dataset = HuatuoDataset(TRAIN_FILE)
eval_dataset = HuatuoDataset(EVAL_FILE)

# =========================
# Data Collator
# =========================
data_collator = DataCollatorForLanguageModeling(tokenizer=tokenizer, mlm=False)

# =========================
# Trainer 设置
# =========================
training_args = TrainingArguments(
    output_dir=OUTPUT_DIR,
    per_device_train_batch_size=BATCH_SIZE,
    per_device_eval_batch_size=BATCH_SIZE,
    gradient_accumulation_steps=GRAD_ACCUM_STEPS,
    num_train_epochs=EPOCHS,
    learning_rate=LR,
    weight_decay=0.0,
    logging_steps=50,
    save_strategy="epoch",
    eval_strategy="epoch",
    save_total_limit=3,
    fp16=True,
    report_to="none",
    load_best_model_at_end=True,
    metric_for_best_model="eval_loss",
)

# =========================
# 自定义日志
# =========================
class LogCallback(TrainerCallback):
    def __init__(self, log_file):
        self.log_file = log_file
        self.logs = []

    def on_log(self, args, state, control, logs=None, **kwargs):
        if logs:
            self.logs.append({"epoch": state.epoch, **logs})
            with open(self.log_file, "w", encoding="utf-8") as f:
                json.dump(self.logs, f, ensure_ascii=False, indent=2)

trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=eval_dataset,
    data_collator=data_collator,
    callbacks=[LogCallback(LOG_FILE)]
)

# =========================
# 训练 & 保存
# =========================
print("🚀 开始训练...")
trainer.train()

model.save_pretrained(OUTPUT_DIR)
tokenizer.save_pretrained(OUTPUT_DIR)
print("🎉 LoRA 微调完成！")
