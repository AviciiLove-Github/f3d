def Model(inText):
	outText = inText + "2"
	return outText